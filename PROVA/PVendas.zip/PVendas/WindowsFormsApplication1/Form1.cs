﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsFormsApplication1
{
    public partial class PVendas : Form
    {
        public PVendas()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            // RA = 0030482213044

            double[,] Valores = new double[4, 4];
            double[] TotalMes = new double[4];
            string valor;
            double totalMeses = 0;


            for (int x = 0; x < 4; x++)
            {
                for (int y = 0; y < 4; y++)
                {
                    valor = Interaction.InputBox("Digite o valor da semana " + (y + 1) + " do mês " + (x + 1), "Entrada de Dados");
                    if (valor == "")
                    {
                        MessageBox.Show("Campo está vazio");
                        y--;
                    }
                    else if (double.TryParse(valor, out Valores[x, y]))
                    {
                        double.TryParse(valor, out Valores[x, y]);
                    }
                    else
                    {
                        MessageBox.Show("Digite apenas números!");
                        y--;
                    }
                }
            }


            for (int x = 0; x < 4; x++)
            {
                for (int y = 0; y < 4; y++)
                {
                    TotalMes[x] = TotalMes[x] + Valores[x, y];
                }
                totalMeses = totalMeses + TotalMes[x];
            }

            for (int x = 0; x < 4; x++)
            {
                for (int y = 0; y < 4; y++)
                {
                    listBoxResultados.Items.Add("Total do mês " + (x + 1) + " na semana " + (y + 1) + ": R$" + Valores[x, y].ToString("N2"));
                }
                listBoxResultados.Items.Add(">>Total do mês: R$" + TotalMes[x].ToString("N2"));
                listBoxResultados.Items.Add("----------------------------------------------------------------------------------------");
            }
            listBoxResultados.Items.Add("**Total geral: R$" + totalMeses.ToString("N2"));
        }

        private void listBoxResultados_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBoxResultados.Items.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}


