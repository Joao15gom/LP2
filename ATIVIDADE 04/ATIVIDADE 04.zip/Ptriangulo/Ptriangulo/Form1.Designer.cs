﻿
namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtClassificacao = new System.Windows.Forms.TextBox();
            this.txtLadoB = new System.Windows.Forms.TextBox();
            this.txtLadoA = new System.Windows.Forms.TextBox();
            this.eblLadoB = new System.Windows.Forms.Label();
            this.eblLadoA = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.eblClassificacao = new System.Windows.Forms.Label();
            this.txtLadoC = new System.Windows.Forms.TextBox();
            this.eblLadoC = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Goudy Old Style", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.ForestGreen;
            this.label1.Location = new System.Drawing.Point(22, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(306, 32);
            this.label1.TabIndex = 28;
            this.label1.Text = "Classicação dos Triângulos";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSair.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.ForeColor = System.Drawing.Color.White;
            this.btnSair.Location = new System.Drawing.Point(170, 219);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(136, 27);
            this.btnSair.TabIndex = 27;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.Green;
            this.btnCalcular.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.ForeColor = System.Drawing.Color.White;
            this.btnCalcular.Location = new System.Drawing.Point(98, 183);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(136, 29);
            this.btnCalcular.TabIndex = 25;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtClassificacao
            // 
            this.txtClassificacao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.txtClassificacao.Enabled = false;
            this.txtClassificacao.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtClassificacao.Location = new System.Drawing.Point(159, 137);
            this.txtClassificacao.Name = "txtClassificacao";
            this.txtClassificacao.Size = new System.Drawing.Size(186, 27);
            this.txtClassificacao.TabIndex = 28;
            // 
            // txtLadoB
            // 
            this.txtLadoB.BackColor = System.Drawing.Color.Green;
            this.txtLadoB.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLadoB.ForeColor = System.Drawing.Color.White;
            this.txtLadoB.Location = new System.Drawing.Point(159, 69);
            this.txtLadoB.Name = "txtLadoB";
            this.txtLadoB.Size = new System.Drawing.Size(104, 27);
            this.txtLadoB.TabIndex = 23;
            // 
            // txtLadoA
            // 
            this.txtLadoA.BackColor = System.Drawing.Color.Green;
            this.txtLadoA.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLadoA.ForeColor = System.Drawing.Color.White;
            this.txtLadoA.Location = new System.Drawing.Point(159, 43);
            this.txtLadoA.Name = "txtLadoA";
            this.txtLadoA.Size = new System.Drawing.Size(104, 27);
            this.txtLadoA.TabIndex = 22;
            // 
            // eblLadoB
            // 
            this.eblLadoB.AutoSize = true;
            this.eblLadoB.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eblLadoB.Location = new System.Drawing.Point(81, 71);
            this.eblLadoB.Name = "eblLadoB";
            this.eblLadoB.Size = new System.Drawing.Size(64, 23);
            this.eblLadoB.TabIndex = 20;
            this.eblLadoB.Text = "Lado B";
            // 
            // eblLadoA
            // 
            this.eblLadoA.AutoSize = true;
            this.eblLadoA.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eblLadoA.Location = new System.Drawing.Point(81, 46);
            this.eblLadoA.Name = "eblLadoA";
            this.eblLadoA.Size = new System.Drawing.Size(65, 23);
            this.eblLadoA.TabIndex = 19;
            this.eblLadoA.Text = "Lado A";
            this.eblLadoA.Click += new System.EventHandler(this.eblLadoA_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.Green;
            this.btnLimpar.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.ForeColor = System.Drawing.Color.White;
            this.btnLimpar.Location = new System.Drawing.Point(28, 219);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(136, 29);
            this.btnLimpar.TabIndex = 26;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.UseWaitCursor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // eblClassificacao
            // 
            this.eblClassificacao.AutoSize = true;
            this.eblClassificacao.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eblClassificacao.ForeColor = System.Drawing.Color.Green;
            this.eblClassificacao.Location = new System.Drawing.Point(35, 137);
            this.eblClassificacao.Name = "eblClassificacao";
            this.eblClassificacao.Size = new System.Drawing.Size(112, 23);
            this.eblClassificacao.TabIndex = 29;
            this.eblClassificacao.Text = "Classificação";
            // 
            // txtLadoC
            // 
            this.txtLadoC.BackColor = System.Drawing.Color.Green;
            this.txtLadoC.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLadoC.ForeColor = System.Drawing.Color.White;
            this.txtLadoC.Location = new System.Drawing.Point(159, 95);
            this.txtLadoC.Name = "txtLadoC";
            this.txtLadoC.Size = new System.Drawing.Size(105, 27);
            this.txtLadoC.TabIndex = 24;
            // 
            // eblLadoC
            // 
            this.eblLadoC.AutoSize = true;
            this.eblLadoC.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eblLadoC.Location = new System.Drawing.Point(81, 97);
            this.eblLadoC.Name = "eblLadoC";
            this.eblLadoC.Size = new System.Drawing.Size(64, 23);
            this.eblLadoC.TabIndex = 30;
            this.eblLadoC.Text = "Lado C";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(357, 262);
            this.Controls.Add(this.txtLadoC);
            this.Controls.Add(this.eblLadoC);
            this.Controls.Add(this.eblClassificacao);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtClassificacao);
            this.Controls.Add(this.txtLadoB);
            this.Controls.Add(this.txtLadoA);
            this.Controls.Add(this.eblLadoB);
            this.Controls.Add(this.eblLadoA);
            this.Controls.Add(this.btnLimpar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtClassificacao;
        private System.Windows.Forms.TextBox txtLadoB;
        private System.Windows.Forms.TextBox txtLadoA;
        private System.Windows.Forms.Label eblLadoB;
        private System.Windows.Forms.Label eblLadoA;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label eblClassificacao;
        private System.Windows.Forms.TextBox txtLadoC;
        private System.Windows.Forms.Label eblLadoC;
    }
}

