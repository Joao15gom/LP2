﻿using System;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void eblLadoA_Click(object sender, EventArgs e)
        {

        }

        private void eblClassificacao_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double A, B, C;
            string Resultado;

            if (Double.TryParse(txtLadoA.Text, out A) &&
                Double.TryParse(txtLadoB.Text, out B) &&
                Double.TryParse(txtLadoC.Text, out C))
            {
                if (((B - C) < A && A < B + C) && ((A - C) < B && B < A + C) && ((A - B) < C && C < A + B))
                {
                    if (A != B && A != C && B != C)
                    {
                        Resultado = "Triângulo Escaleno";
                        txtClassificacao.Text = Resultado;
                        return;
                    }
                    else
                    {
                        if (A == B && A == C && B == C)
                        {
                            Resultado = "Triângulo Equilátero";
                            txtClassificacao.Text = Resultado;
                        }
                        else
                        {
                            Resultado = "Triângulo Isóceles";
                            txtClassificacao.Text = Resultado;
                        }
                    }
                }
                else
                {
                    Resultado = "Não é um Triângulo";
                    txtClassificacao.Text = Resultado;
                }
            }
            else
            {
                MessageBox.Show("Valores Inválidos", "ATENÇÃO");
                txtLadoA.Clear();
                txtLadoB.Clear();
                txtLadoC.Clear(); 
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //Limpar todos os dados
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
            txtClassificacao.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
