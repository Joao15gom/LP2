﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void eblPeso_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void eblAltura_Click(object sender, EventArgs e)
        {

        }

        private void eblIMC_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double peso, altura, imc;

            if (Double.TryParse(txtPeso.Text, out peso) &&
                Double.TryParse(txtAltura.Text, out altura))
            {
                imc = peso / Math.Pow (altura, 2);
                txtIMC.Text = imc.ToString("N1");

                if (imc < 18.5)
                    MessageBox.Show("Magreza", "Classificação");
                if (imc >= 18.5 && imc <= 24.9)
                    MessageBox.Show("Normal", "Classificação");
                if (imc >= 25 && imc <= 29.9)
                    MessageBox.Show("Sobrepeso", "Classificação");
                if (imc >= 30 && imc <= 39.9)
                    MessageBox.Show("Obesidade", "Classificação");
                if (imc >= 40)
                    MessageBox.Show("Obesidade Grave", "Classificação");
            }
            else
            {
                MessageBox.Show("Valores Inválidos");
                txtPeso.Clear();
                txtAltura.Clear();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //Limpar todos os dados
            txtPeso.Clear();
            txtAltura.Clear();
            txtIMC.Clear();
        }

        private void txtIMC_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
