﻿namespace Psalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblNumFil = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.numNumFil = new System.Windows.Forms.NumericUpDown();
            this.btnVerDesc = new System.Windows.Forms.Button();
            this.lblAliINSS = new System.Windows.Forms.Label();
            this.mskbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.gpbxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnMas = new System.Windows.Forms.RadioButton();
            this.rbtnFem = new System.Windows.Forms.RadioButton();
            this.lblAliIRPF = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblSalLiq = new System.Windows.Forms.Label();
            this.txtAliINSS = new System.Windows.Forms.TextBox();
            this.txtAliIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiq = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl = new System.Windows.Forms.Label();
            this.lblDados = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnSolteiro = new System.Windows.Forms.RadioButton();
            this.rbtnCasado = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numNumFil)).BeginInit();
            this.gpbxSexo.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(22, 30);
            this.lblNome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(155, 17);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome do Funcionário(a):";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalBruto.Location = new System.Drawing.Point(22, 55);
            this.lblSalBruto.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(86, 17);
            this.lblSalBruto.TabIndex = 2;
            this.lblSalBruto.Text = "Salário Bruto:";
            // 
            // lblNumFil
            // 
            this.lblNumFil.AutoSize = true;
            this.lblNumFil.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumFil.Location = new System.Drawing.Point(22, 79);
            this.lblNumFil.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNumFil.Name = "lblNumFil";
            this.lblNumFil.Size = new System.Drawing.Size(112, 17);
            this.lblNumFil.TabIndex = 4;
            this.lblNumFil.Text = "Número de Filhos:";
            this.lblNumFil.Click += new System.EventHandler(this.lblNumFil_Click);
            // 
            // txtNome
            // 
            this.txtNome.BackColor = System.Drawing.Color.Silver;
            this.txtNome.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(182, 25);
            this.txtNome.Margin = new System.Windows.Forms.Padding(2);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(269, 22);
            this.txtNome.TabIndex = 1;
            // 
            // numNumFil
            // 
            this.numNumFil.BackColor = System.Drawing.Color.Silver;
            this.numNumFil.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numNumFil.Location = new System.Drawing.Point(138, 78);
            this.numNumFil.Margin = new System.Windows.Forms.Padding(2);
            this.numNumFil.Name = "numNumFil";
            this.numNumFil.Size = new System.Drawing.Size(80, 22);
            this.numNumFil.TabIndex = 5;
            this.numNumFil.ValueChanged += new System.EventHandler(this.numNumFil_ValueChanged);
            // 
            // btnVerDesc
            // 
            this.btnVerDesc.BackColor = System.Drawing.Color.Silver;
            this.btnVerDesc.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerDesc.ForeColor = System.Drawing.Color.Blue;
            this.btnVerDesc.Location = new System.Drawing.Point(138, 175);
            this.btnVerDesc.Margin = new System.Windows.Forms.Padding(2);
            this.btnVerDesc.Name = "btnVerDesc";
            this.btnVerDesc.Size = new System.Drawing.Size(198, 27);
            this.btnVerDesc.TabIndex = 6;
            this.btnVerDesc.Text = "Verificar Descontos";
            this.btnVerDesc.UseVisualStyleBackColor = false;
            this.btnVerDesc.Click += new System.EventHandler(this.btnVerDesc_Click);
            // 
            // lblAliINSS
            // 
            this.lblAliINSS.AutoSize = true;
            this.lblAliINSS.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliINSS.Location = new System.Drawing.Point(23, 231);
            this.lblAliINSS.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAliINSS.Name = "lblAliINSS";
            this.lblAliINSS.Size = new System.Drawing.Size(91, 17);
            this.lblAliINSS.TabIndex = 7;
            this.lblAliINSS.Text = "Alíquota INSS:";
            // 
            // mskbxSalBruto
            // 
            this.mskbxSalBruto.BackColor = System.Drawing.Color.Silver;
            this.mskbxSalBruto.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskbxSalBruto.Location = new System.Drawing.Point(137, 51);
            this.mskbxSalBruto.Margin = new System.Windows.Forms.Padding(2);
            this.mskbxSalBruto.Mask = "999999.90";
            this.mskbxSalBruto.Name = "mskbxSalBruto";
            this.mskbxSalBruto.Size = new System.Drawing.Size(81, 22);
            this.mskbxSalBruto.TabIndex = 3;
            this.mskbxSalBruto.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mskbxSalBruto_MaskInputRejected);
            // 
            // gpbxSexo
            // 
            this.gpbxSexo.Controls.Add(this.rbtnMas);
            this.gpbxSexo.Controls.Add(this.rbtnFem);
            this.gpbxSexo.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbxSexo.Location = new System.Drawing.Point(26, 106);
            this.gpbxSexo.Margin = new System.Windows.Forms.Padding(2);
            this.gpbxSexo.Name = "gpbxSexo";
            this.gpbxSexo.Padding = new System.Windows.Forms.Padding(2);
            this.gpbxSexo.Size = new System.Drawing.Size(108, 65);
            this.gpbxSexo.TabIndex = 9;
            this.gpbxSexo.TabStop = false;
            this.gpbxSexo.Text = "Sexo";
            // 
            // rbtnMas
            // 
            this.rbtnMas.AutoSize = true;
            this.rbtnMas.Location = new System.Drawing.Point(7, 36);
            this.rbtnMas.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnMas.Name = "rbtnMas";
            this.rbtnMas.Size = new System.Drawing.Size(86, 21);
            this.rbtnMas.TabIndex = 8;
            this.rbtnMas.Text = "Masculino";
            this.rbtnMas.UseVisualStyleBackColor = true;
            // 
            // rbtnFem
            // 
            this.rbtnFem.AutoSize = true;
            this.rbtnFem.Checked = true;
            this.rbtnFem.Location = new System.Drawing.Point(7, 17);
            this.rbtnFem.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnFem.Name = "rbtnFem";
            this.rbtnFem.Size = new System.Drawing.Size(79, 21);
            this.rbtnFem.TabIndex = 7;
            this.rbtnFem.TabStop = true;
            this.rbtnFem.Text = "Feminino";
            this.rbtnFem.UseVisualStyleBackColor = true;
            // 
            // lblAliIRPF
            // 
            this.lblAliIRPF.AutoSize = true;
            this.lblAliIRPF.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliIRPF.Location = new System.Drawing.Point(23, 254);
            this.lblAliIRPF.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAliIRPF.Name = "lblAliIRPF";
            this.lblAliIRPF.Size = new System.Drawing.Size(88, 17);
            this.lblAliIRPF.TabIndex = 11;
            this.lblAliIRPF.Text = "Alíquota IRPF:";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalFamilia.Location = new System.Drawing.Point(23, 277);
            this.lblSalFamilia.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(97, 17);
            this.lblSalFamilia.TabIndex = 12;
            this.lblSalFamilia.Text = "Salário Família:";
            // 
            // lblSalLiq
            // 
            this.lblSalLiq.AutoSize = true;
            this.lblSalLiq.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalLiq.Location = new System.Drawing.Point(23, 301);
            this.lblSalLiq.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSalLiq.Name = "lblSalLiq";
            this.lblSalLiq.Size = new System.Drawing.Size(98, 17);
            this.lblSalLiq.TabIndex = 13;
            this.lblSalLiq.Text = "Salário Líquido:";
            // 
            // txtAliINSS
            // 
            this.txtAliINSS.Enabled = false;
            this.txtAliINSS.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAliINSS.Location = new System.Drawing.Point(138, 230);
            this.txtAliINSS.Margin = new System.Windows.Forms.Padding(2);
            this.txtAliINSS.Name = "txtAliINSS";
            this.txtAliINSS.Size = new System.Drawing.Size(81, 22);
            this.txtAliINSS.TabIndex = 14;
            this.txtAliINSS.TextChanged += new System.EventHandler(this.txtAliINSS_TextChanged_1);
            // 
            // txtAliIRPF
            // 
            this.txtAliIRPF.Enabled = false;
            this.txtAliIRPF.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAliIRPF.Location = new System.Drawing.Point(138, 253);
            this.txtAliIRPF.Margin = new System.Windows.Forms.Padding(2);
            this.txtAliIRPF.Name = "txtAliIRPF";
            this.txtAliIRPF.Size = new System.Drawing.Size(81, 22);
            this.txtAliIRPF.TabIndex = 15;
            this.txtAliIRPF.TextChanged += new System.EventHandler(this.txtAliIRPF_TextChanged);
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Enabled = false;
            this.txtSalFamilia.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalFamilia.Location = new System.Drawing.Point(138, 276);
            this.txtSalFamilia.Margin = new System.Windows.Forms.Padding(2);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(82, 22);
            this.txtSalFamilia.TabIndex = 16;
            this.txtSalFamilia.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // txtSalLiq
            // 
            this.txtSalLiq.Enabled = false;
            this.txtSalLiq.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalLiq.Location = new System.Drawing.Point(138, 299);
            this.txtSalLiq.Margin = new System.Windows.Forms.Padding(2);
            this.txtSalLiq.Name = "txtSalLiq";
            this.txtSalLiq.Size = new System.Drawing.Size(81, 22);
            this.txtSalLiq.TabIndex = 17;
            this.txtSalLiq.TextChanged += new System.EventHandler(this.txtSalLiq_TextChanged);
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescIRPF.Location = new System.Drawing.Point(138, 345);
            this.txtDescIRPF.Margin = new System.Windows.Forms.Padding(2);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(81, 22);
            this.txtDescIRPF.TabIndex = 21;
            this.txtDescIRPF.TextChanged += new System.EventHandler(this.txtDescIRPF_TextChanged);
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescINSS.Location = new System.Drawing.Point(138, 322);
            this.txtDescINSS.Margin = new System.Windows.Forms.Padding(2);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(81, 22);
            this.txtDescINSS.TabIndex = 20;
            this.txtDescINSS.TextChanged += new System.EventHandler(this.txtDescINSS_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 346);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 17);
            this.label1.TabIndex = 19;
            this.label1.Text = "Desconto IRPF:";
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl.Location = new System.Drawing.Point(23, 324);
            this.lbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(98, 17);
            this.lbl.TabIndex = 18;
            this.lbl.Text = "Desconto INSS:";
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDados.ForeColor = System.Drawing.Color.Blue;
            this.lblDados.Location = new System.Drawing.Point(22, 203);
            this.lblDados.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(183, 20);
            this.lblDados.TabIndex = 22;
            this.lblDados.Text = "Dados do Funcinário(a):";
            this.lblDados.Click += new System.EventHandler(this.lblDados_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnSolteiro);
            this.groupBox1.Controls.Add(this.rbtnCasado);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(164, 106);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(112, 65);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Estado Cívil";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // rbtnSolteiro
            // 
            this.rbtnSolteiro.AutoSize = true;
            this.rbtnSolteiro.Location = new System.Drawing.Point(7, 36);
            this.rbtnSolteiro.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnSolteiro.Name = "rbtnSolteiro";
            this.rbtnSolteiro.Size = new System.Drawing.Size(89, 21);
            this.rbtnSolteiro.TabIndex = 10;
            this.rbtnSolteiro.Text = "Solteiro(a)";
            this.rbtnSolteiro.UseVisualStyleBackColor = true;
            // 
            // rbtnCasado
            // 
            this.rbtnCasado.AutoSize = true;
            this.rbtnCasado.Checked = true;
            this.rbtnCasado.Location = new System.Drawing.Point(7, 17);
            this.rbtnCasado.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnCasado.Name = "rbtnCasado";
            this.rbtnCasado.Size = new System.Drawing.Size(89, 21);
            this.rbtnCasado.TabIndex = 9;
            this.rbtnCasado.TabStop = true;
            this.rbtnCasado.Text = "Casado(a)";
            this.rbtnCasado.UseVisualStyleBackColor = true;
            this.rbtnCasado.CheckedChanged += new System.EventHandler(this.rbtnCasado_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(22, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 19);
            this.label2.TabIndex = 24;
            this.label2.Text = "Calcule seu Salário";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(468, 374);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.txtSalLiq);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliIRPF);
            this.Controls.Add(this.txtAliINSS);
            this.Controls.Add(this.lblSalLiq);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblAliIRPF);
            this.Controls.Add(this.gpbxSexo);
            this.Controls.Add(this.mskbxSalBruto);
            this.Controls.Add(this.lblAliINSS);
            this.Controls.Add(this.btnVerDesc);
            this.Controls.Add(this.numNumFil);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblNumFil);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNome);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Cálculo Salário";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numNumFil)).EndInit();
            this.gpbxSexo.ResumeLayout(false);
            this.gpbxSexo.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblNumFil;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.NumericUpDown numNumFil;
        private System.Windows.Forms.Button btnVerDesc;
        private System.Windows.Forms.Label lblAliINSS;
        private System.Windows.Forms.MaskedTextBox mskbxSalBruto;
        private System.Windows.Forms.GroupBox gpbxSexo;
        private System.Windows.Forms.RadioButton rbtnFem;
        private System.Windows.Forms.Label lblAliIRPF;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblSalLiq;
        private System.Windows.Forms.TextBox txtAliINSS;
        private System.Windows.Forms.TextBox txtAliIRPF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiq;
        private System.Windows.Forms.RadioButton rbtnMas;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtnCasado;
        private System.Windows.Forms.RadioButton rbtnSolteiro;
        private System.Windows.Forms.Label label2;
    }
}

