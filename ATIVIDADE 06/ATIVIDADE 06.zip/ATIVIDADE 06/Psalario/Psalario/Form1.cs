﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAliINSS_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnVerDesc_Click(object sender, EventArgs e)
        {
            Double salBruto, numFilhos = 0, aliqINSS = 0, aliqIRPF = 0, salFamilia, salLiquido = 0, descIRPF = 0, descINSS = 0;

            if (Double.TryParse(mskbxSalBruto.Text, out salBruto) &&
                (txtNome.Text != "") &&
                Double.TryParse(numNumFil.Text, out numFilhos))
            {
                if (salBruto >= 0)
                {
                    //para verificar qual a aliquota INSS
                    if (salBruto <= 800.47)
                        aliqINSS = 0.0765;
                    else if (salBruto <= 1050)
                        aliqINSS = 0.0865;
                    else if (salBruto <= 1400.77)
                        aliqINSS = 0.09;
                    else if (salBruto <= 2801.56)
                        aliqINSS = 0.11;
                    else
                        aliqINSS = 0.11;

                    //para calcular o desconto INSS
                    descINSS = salBruto * aliqINSS;
                    aliqINSS = aliqINSS * 100;

                    //para exibir a aliquota INSS
                    if (salBruto > 2801.56)
                    {
                        descINSS = 308.17;
                        txtAliINSS.Text = "Teto";
                    }
                    else
                        txtAliINSS.Text = aliqINSS.ToString("N2") + "%";

                    //para exibir o desconto do INSS
                    txtDescINSS.Text = "R$" + descINSS.ToString("N2");

                    //para verificar aliquota IRPF
                    if (salBruto <= 1257.12)
                        aliqIRPF = 0;
                    else if (salBruto <= 2510.08)
                        aliqIRPF = 0.15;
                    else
                        aliqIRPF = 0.275;

                    //para calcular o desconto IRPF
                    descIRPF = salBruto * aliqIRPF;
                    aliqIRPF = aliqIRPF * 100;

                    //para exibir aliquota IRPF
                    if (aliqIRPF == 0)
                        txtAliIRPF.Text = "Isento";
                    else
                        txtAliIRPF.Text = aliqIRPF.ToString("n2") + "%";

                    //para exibir desconto IRPF
                    txtDescIRPF.Text = "R$" + descIRPF.ToString("N2");

                    //para verificar salario familia
                    if (salBruto <= 435.52)
                        salFamilia = 22.33 * numFilhos;
                    else if (salBruto <= 654.61)
                        salFamilia = 15.74 * numFilhos;
                    else
                        salFamilia = 0;
                    txtSalFamilia.Text = "R$" + salFamilia.ToString("N2");


                    //para calcular salario liquido
                    salLiquido = salBruto - descINSS - descIRPF + salFamilia;
                    txtSalLiq.Text = "R$" + salLiquido.ToString("N2");

                    //para aparecer a mensagem de informações do funcionário
                    if (rbtnFem.Checked)
                        if (rbtnCasado.Checked)
                            lblDados.Text = "A funcionária " + txtNome.Text + ", é casada e possui " + numNumFil.Text + " filhos.";
                        else
                            lblDados.Text = "A funcionária " + txtNome.Text + ", é solteira e possui " + numNumFil.Text + " filhos.";
                    else if (rbtnCasado.Checked)
                        lblDados.Text = "O funcionário " + txtNome.Text + ", é casado e possui " + numNumFil.Text + " filhos.";
                    else
                        lblDados.Text = "O funcionário " + txtNome.Text + ", é solteiro e possui " + numNumFil.Text + " filhos.";

                }
                else
                {
                    MessageBox.Show("O salário deve ser maior que 0!");
                }


            }
            else
            {
                MessageBox.Show("Certifique-se de os campos 'Nome' e 'Salário' estão preenchidos!");
                mskbxSalBruto.Clear();
                txtNome.Clear();
                txtNome.Focus();
            }
        }

        private void lblNumFil_Click(object sender, EventArgs e)
        {

        }

        private void lblDados_Click(object sender, EventArgs e)
        {

        }

        private void mskbxSalBruto_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtDescINSS_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSalLiq_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAliIRPF_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAliINSS_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void numNumFil_ValueChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void rbtnCasado_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtDescIRPF_TextChanged(object sender, EventArgs e)
        {

        }
    }
}